# LOADai

## i-have-adhd

[`i-have-adhd/`](./i-have-adhd) vendors [ayghri/i-have-adhd](https://github.com/ayghri/i-have-adhd), a Claude Code skill/plugin that makes coding assistants give ADHD-friendly, action-first responses: next step first, numbered steps, no filler. See [`i-have-adhd/README.md`](./i-have-adhd/README.md) for install and usage.